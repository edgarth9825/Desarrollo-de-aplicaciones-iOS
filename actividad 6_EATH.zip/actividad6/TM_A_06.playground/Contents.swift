import UIKit
/*:
# Playground - Actividad 6
* Operadores personalizados
* Subscripts
* Control de errores

*/


/*: 
### Operadores personalizados
A) Crear el operador para realizar la potencia de el valor "a" a la potencia "b" en valores enteros
*/
prefix operator ^^^
var a:Decimal = 2
var b = 4

prefix func ^^^ (valor:Int)
{
    let valor = pow(a,b)
    print("El valor aumentado a la potencia es: ", valor)
}
^^^4
//: B) Crear el operador |> para ordenar la colección [2,5,3,4] de menor a mayor
infix operator |>
var coleccion2:[Int] = [2,5,3,4]

coleccion2.sort()
print("Los valores ordenados son: ",coleccion2)
/*:
### Subscripts
A) Del conjunto de datos en el Array [2,3,4,5], crear el subscript para modificar los valores multiplicados por el valor 2 y extraer al valor dado un índice.
*/
let numeros = [2,3,4,5]

class Multiplicar
{
    var valores: [Int]
    init(v:[Int]) {
        self.valores = v
    }
    
    subscript (idx:Int)->Int{
        get
        {
            return valores[idx]
        }
        set(valorMultiplicado)
        {
            valores[idx] = valorMultiplicado * 2
        }
    }
}

var v1 = Multiplicar(v: numeros)

v1[2] = v1[2]
v1.valores
print("El valor en la posicion 2 multiplicado por 2 es: ", v1[2])
//: B) Crear el Struct para definir u obtener la posición  para los personaje de tipo Enemigo donde cada posición es de tipo CGPoint aplicnado subscritps
struct enemigos
{
    var posY:CGPoint
    var posX:CGPoint
    
    init(posY:CGPoint, posX:CGPoint) {
        self.posY = posY
        self.posX = posX
    }
    
    func QuePosicion() -> (CGPoint, CGPoint) {
        return(self.posY, self.posX)
    }
    
    /*subscript (idx:CGPoint)->CGPoint
    {
        get
        {
            return posY[idx]
        }
        set(valorMultiplicado)
        {
            valores[idx] = valorMultiplicado * 2
        }
    }*/

}

/*:
### Control de Errores
A) Crear la función ExisteValor en la cual se reciba como parámetro el valor a buscar dentro de un colección ["A":1, "B":2,"C":3]
*/
let coleccion = ["A":1, "B":2,"C":3]

func ExisteValor (idx:String)
{
    guard let existe = coleccion [idx] else {
        print ("No existe")
        return
    }
    
    print("existe \(existe)")
}

ExisteValor(idx: "D")
coleccion ["D"]
