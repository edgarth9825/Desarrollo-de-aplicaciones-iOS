import UIKit

var str = "Actividad 2, menus del entorno Xcode"
var nombre = "Edgar Arturo Torres Hernández 2743927"
