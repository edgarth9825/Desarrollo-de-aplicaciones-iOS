import UIKit
/*:
# Playground - Actividad 5
* Class y Struct
* Extension
* Optional
*/


/*: 
### Actividad Class y Struct
A) Diseñar la clase Persona que contenga dos metodos, el primero "Saludar" que reciba el parámetro nombre y regrese el mensaje el nombre mas el texto "mucho gusto", el segundo metodo "Caminar" que reciba como parámetro un tipo de dato Int y regrese un tipo de dato String indicando el numero de pasos caminados.
*/
class Persona {
    var nombre:String = ""
    var saludo: String = ""
    var camino:Int = 0
    
    init (nombre:String, camino:Int) {
        self.nombre = nombre
        self.camino = camino
    }
    
    func Saludar(mensaje:String) {
        self.saludo = mensaje
    }
    
    func Caminar(pasos:Int) {
        self.camino = pasos
    }
    
}

var edgar = Persona(nombre: "Edgar", camino: 20)
print(edgar.nombre, " mucho gusto ", "pasos que camino: ", edgar.camino)
//: B) Diseñar el struct "Pantalla" la cual recibirá como como parametros el ancho y alto de una pantalla como tipo de datos Int con un constructor, para inicializar la estructura.
struct Pantalla {
    var alto:Int
    var ancho:Int
    
    init(alto:Int, ancho:Int) {
        self.alto = alto
        self.ancho = ancho
    }
}

var fullhd = Pantalla(alto: 1080, ancho: 1920)
print("La resolucion de la pantalla es: ", fullhd.ancho, " x ", fullhd.alto)

/*:
### Extensions
A) Diseñar un extensión del tipo de dato Int que represente las horas y que pueda regresar los segundos correspondientes (puedes utilizar una función o una variable computada)
*/
extension Int {
    func horas() -> Int {
        return self*24*60
    }
}

3.horas()




/*:
### Optionals
A) Diseñar una variable optional para recibir el tipo de dato Int en caso de que exista.
*/
let optional = ["1":1, "2":2, "4":4, "5":5, "6":6]
var existe1:Int?

existe1 = optional ["3"]

if let temp = optional["3"] {
    print("Si existe")
}else {
    print("No existe el numero 3")
}
//: B) Para la colección let dias = ["GDL":120, "PUE":300, "MTY":100, "CDMX":200] diseñar una variable opcional para recibir el valor de dias["DF"]
let dias = ["GDL":120, "PUE":300, "MTY":100, "CDMX":200]
var existe:Int?

existe = dias ["DF"]

if let temp = dias["DF"] {
    print("Si existe")
}else {
    print("No existe DF")
}





