import UIKit
/*:
# Playground - Actividad 4
* Condicionales y Ciclos
* Funciones
* Enumareción
*/



/*:
### Condicionales y Ciclos
A) Declarar la variable "datos" con los valores [3,6,9,2,4,1]
*/
var datos = [3,6,9,2,4,1]
//: B) realizar el recorrido de la variable "datos" con la instrucción "for"
for i in datos {
    print(i)
}

//: C) Encontrar los valores menores a 5
print("Los valores menores a 5 son:")
for i in datos {
    if i < 5 {
        print(i)
    }
    
}

/*:
### Funciones
A) Crea la función "suma" que reciba dos parámetros de tipo entero regresando la suma de ambos números.
*/

    func suma(a:Int,b:Int) -> Int{
        return a + b
    }
    print(suma(a:8,b:1))

    
//: B) Crear la función "potencia" que reciba dos parámetros de tipo entero, el primer parámetro para el numero base y el segundo la potencia a elevar, regresando el resultado de la potencia.
func potencia(a:Int,b:Int) -> Int{
    var x = b
    var total = a
    repeat{
        total = total*a
        x = (x-1)
    }while (x>1)
    return total
}
    print(potencia(a:2,b:3))

/*:
### Enumeraciones
A) Crea la enumaración "meses" para definir tipos de datos basados en los meses del año.
*/

enum meses{
    case enero,febrero,marzo,abril,mayo,junio,julio,agosto,septiembre,octubre,noviembre,diciembre
}


//: B) Crear la función "numeroMes" que reciba el tipo de dato "meses" y regrese el numero del mes correspondiente
func numeroMes(meses:String) -> String{
    return meses
}


//: C) Para regresar el numero de mes correspondiente utilizar la "switch"

let mes:meses = .marzo

switch mes{
case .enero:
    print("Enero es el mes numero: 1")
case .febrero:
    print("Febrero es el mes numero: 2")
case .marzo:
    print("Marzo es el mes numero: 3")
case .abril:
    print("Abril es el mes numero: 4")
case .mayo:
    print("Mayo es el mes numero: 5")
case .junio:
    print("Junio es el mes numero: 6")
case .julio:
    print("Julio es el mes numero: 7")
case .agosto:
    print("Agosto es el mes numero: 8")
case .septiembre:
    print("Septiembre es el mes numero: 9")
case .octubre:
    print("Octubre es el mes numero: 10")
case .noviembre:
    print("Noviembre es el mes numero: 11")
case .diciembre:
    print("Diciembre es el mes numero: 12")
}




